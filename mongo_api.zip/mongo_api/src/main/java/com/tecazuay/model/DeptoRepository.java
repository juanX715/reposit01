package com.tecazuay.model;


import org.springframework.data.mongodb.repository.MongoRepository;

public interface DeptoRepository extends MongoRepository<Depto, String> {
}
