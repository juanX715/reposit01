package com.tecazuay.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tecazuay.model.Depto;
import com.tecazuay.model.DeptoRepository;

import java.util.List;

@RestController
@RequestMapping("/api/deptos")
public class DeptoController {

	

	    @Autowired
	    private DeptoRepository deptoRepository;

	    // Obtener todos los departamentos
	    @GetMapping
	    public List<Depto> getAllDeptos() {
	        return deptoRepository.findAll();
	    }

	    // Crear un nuevo departamento
	    @PostMapping
	    public Depto createDepto(@RequestBody Depto depto) {
	        return deptoRepository.save(depto);
	    }

	    // Actualizar un departamento existente
	    @PutMapping("/{id}")
	    public ResponseEntity<Depto> updateDepto(@PathVariable String id, @RequestBody Depto deptoDetails) {
	        return deptoRepository.findById(id)
	                .map(depto -> {
	                    depto.setNombre(deptoDetails.getNombre());
	                    depto.setDirector(deptoDetails.getDirector());
	                    depto.setDescripcion(deptoDetails.getDescripcion());
	                    return ResponseEntity.ok(deptoRepository.save(depto));
	                }).orElse(ResponseEntity.notFound().build());
	    }

	    // Eliminar un departamento
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Object> deleteDepto(@PathVariable String id) {
	        return deptoRepository.findById(id)
	                .map(depto -> {
	                    deptoRepository.delete(depto);
	                    return ResponseEntity.ok().build();
	                }).orElse(ResponseEntity.notFound().build());
	    }
	}
