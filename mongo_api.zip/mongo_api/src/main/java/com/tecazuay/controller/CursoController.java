package com.tecazuay.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tecazuay.model.Curso;
import com.tecazuay.model.CursoRepository;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
public class CursoController {


	    @Autowired
	    private CursoRepository cursoRepository;

	    // Obtener todos los cursos
	    @GetMapping
	    public List<Curso> getAllCursos() {
	        return cursoRepository.findAll();
	    }

	    // Crear un nuevo curso
	    @PostMapping
	    public Curso createCurso(@RequestBody Curso curso) {
	        return cursoRepository.save(curso);
	    }

	    // Actualizar un curso existente
	    @PutMapping("/{id}")
	    public ResponseEntity<Curso> updateCurso(@PathVariable String id, @RequestBody Curso cursoDetails) {
	        return cursoRepository.findById(id)
	                .map(curso -> {
	                    curso.setNombre(cursoDetails.getNombre());
	                    curso.setNivel(cursoDetails.getNivel());
	                    curso.setDescripcion(cursoDetails.getDescripcion());
	                    curso.setProfId(cursoDetails.getProfId());
	                    return ResponseEntity.ok(cursoRepository.save(curso));
	                }).orElse(ResponseEntity.notFound().build());
	    }

	    // Eliminar un curso
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Object> deleteCurso(@PathVariable String id) {
	        return cursoRepository.findById(id)
	                .map(curso -> {
	                    cursoRepository.delete(curso);
	                    return ResponseEntity.ok().build();
	                }).orElse(ResponseEntity.notFound().build());
	    }
	}
