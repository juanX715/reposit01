package com.tecazuay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
