/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Juan
 */
@WebService(serviceName = "OperacionesSW")
public class OperacionesSW {

  
    /**
     * Web service operation
     */
    @WebMethod(operationName = "sumar")
    public Double sumar(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1+num2;
    }
    
     @WebMethod(operationName = "restar")
    public Double restar(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1-num2;
    }
    
     @WebMethod(operationName = "multiplicar")
    public Double multiplicar(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1*num2;
    }
    
     @WebMethod(operationName = "dividir")
    public Double dividir(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2) {
        //TODO write your implementation code here:
        return num1/num2;
    }
}
