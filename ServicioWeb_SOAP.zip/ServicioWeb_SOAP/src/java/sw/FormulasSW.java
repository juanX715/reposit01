/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Juan
 */
@WebService(serviceName = "FormulasSW")
public class FormulasSW {

    /**
     * This is a sample web service operation
    }  */
    
    
    @WebMethod(operationName = "area_circulo")
    public Double area_circulo(@WebParam(name = "radio") double radio) {
        //TODO write your implementation code here:
        return radio*radio*3.14;
    }
    
    @WebMethod(operationName = "perimetro_circulo")
    public Double perimetro_circulo(@WebParam(name = "radio") double radio) {
        //TODO write your implementation code here:
        return radio*2*3.14;
    }

     @WebMethod(operationName = "hipotenusa")
    public Double hipotenusa(@WebParam(name = "cateto1") double cateto1, @WebParam(name = "cateto2") double cateto2) {
        //TODO write your implementation code here:
        return (cateto1*cateto1)+(cateto2*cateto2);
    }

}
